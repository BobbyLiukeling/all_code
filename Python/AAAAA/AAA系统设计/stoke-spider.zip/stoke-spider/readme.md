spider.py:
包括股票名的爬取和网页的爬取
stoke_h.py:
存入Excel文件
stoke_sql.py:
存入数据库
plot.py:
制图及存储图像
stoke_gui.py:
GUI界面
运行：
python stoke_gui.py

